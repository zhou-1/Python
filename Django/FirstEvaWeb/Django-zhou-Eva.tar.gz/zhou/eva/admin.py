from django.contrib import admin

# Register your models here.
from eva.models import Category, Page
from eva.models import UserProfile

class PageAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'url')

class CatAdmin(admin.ModelAdmin):
    list_display = ('name','slug', 'views', 'likes')  
    prepopulated_fields = {'slug':('name',)} 

admin.site.register(Category, CatAdmin)
admin.site.register(Page, PageAdmin)
admin.site.register(UserProfile)


