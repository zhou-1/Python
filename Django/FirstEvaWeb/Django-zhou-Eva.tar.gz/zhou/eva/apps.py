from django.apps import AppConfig


class RevaConfig(AppConfig):
    name = 'reva'
